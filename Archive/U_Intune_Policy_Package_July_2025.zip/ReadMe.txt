WARNING
-------

It must be noted that the Intune policies provided should be evaluated in a representative test environment before implementation within production environments. The extensive variety of environments makes it impossible to test these MEM policies for all potential enterprise and software configurations. For most environments, failure to test before implementation may lead to a loss of required functionality.


INTRODUCTION
------------

This package contains JSON backup exports. It is to provide enterprise administrators the supporting Intune policies and related files to aid them in the deployment of Intune within their enterprise to meet STIG settings. Administrators are expected to fully test policies in test environments prior to live production deployments.

Administrators can locate the documented STIG compliance in corresponding STIG Checklist file contained within the DISA STIG GPO Package (Support Files\Checklist Files). The checklist file provides the appropriate device configuration profile setting is located i.e. Endpoint Security baseline, Administrative template, Custom profile, or Endpoint protection.


MAINTENANCE
-----------

This package will be updated with each quarterly release of STIG updates. If a targeted STIG within package is released out of cycle, the package will be updated accordingly. Additional if a new STIG is targeted to provide a supporting policy, the package will be updated to include JSON backup.

The initial release of DISA Intune STIG Package is targeted for Windows 10/11 systems. Mobile device management is out of scope currently. Administrators may find iOS, macOS and Android device configurations profiles within the corresponding STIG downloads on CyberMIL.


USAGE
-----

This package is to be used to assist administrators implementing STIG settings within their environment. The administrator must fully test policies in test environments prior to live production deployments. The policies provided contain most applicable and restrictive STIG settings contained in STIG files. 

The Microsoft 365 Administrative Template profile will apply to all Microsoft Office 2016, Microsoft Office 2019, and M365 Apps.

In Co-management environment, administrators must configure the appropriate workload to apply Intune policies. It is not intended this package be a deployment guide for administrators.

January 2023
------------
Inclusion of Settings Catalog profiles. The settings catalog is intended to support environments in co-management and not all workloads are migrated. The settings catalog is near "all-inclusive" configuration of Windows STIG requirements. In environments where the MS Security baselines are being used there is no need to migrate to catalog settings as existing MS Security Baseline profile layered with the appropriate device configuration administrative template, endpoint security and custom profile will achieve STIG compliance.

Added device configuration profiles Edge, Chrome, and Firefox for macOS to meet STIG requirements.

Added PowerShell scripts to assist in completing configurations to meet STIG requirements where no configuration item is available with native tools.

Third-party administrative template profiles will require import of the ADMX files. The ADMX files can be located under the ADMX Template directory in root of STIG Baseline (ADMX Templates). Administrative template profiles are intended to phase out the need for custom OMA-URI profiles

March 2024
----------
Removed Endpoint Security Microsoft Security Baseline profiles, Windows 10/11 Custom Profiles, and Administrative Template Profiles in favor of leveraging Setting Catalog Profiles for endpoint configurations. 

Setting Catalog Profiles allow for all settings for the operating system or targeted application to be contained in a single profile versus in multiple profiles to meet STIG requirements.

The Microsoft Edge macOS Settings Catalog does NOT meet all STIG requirements. There are several settings not available for configuration. Administrators are encouraged to use the Microsoft Edge macOS Preference File profile to meet all STIG requirements. Administrators may be required to modify Proxy Server, and extension configurations to meet organizations operational requirements. The plist files are provided under the Support Files\macOS directory.

September 2024
--------------
Added DSC STIG Configurations under Support Files\Windows. DSC STIG Configurations intunewin application closes the gaps for STIG compliance where settings are not available in Intune.

Added PowerShell Scripts under Support Files\Windows. Remove-Windows-Apps.ps1 is intended to assist administrators in removal of many built-in Windows appx packages.

Added Custom Compliance Policy under Support Files\Windows. This is a sample of a custom compliance script for all STIG CAT 1 items. Administrators are encouraged NOT to use "as is" as many environments relax STIG requirements for operational needs. Implementing "as is" may result in devices reporting Not Compliant and prevent access based on operation Conditional Access policies.

Added Android Managed Device Google Chrome STIG v2r10 App Configuration Policy. The app configuration policy does NOT meet all required STIG settings. Many settings are not available. Additional app configuration policy to be added in later releases.

Added Custom Policy import PowerShell scripts under Support Files\Windows\PowerShell Scripts\CustomPolicyImport.

Depreciated settings ChromeCleanupEnabled, ChromeCleanupReportingEnabled, and SSLVersionMin have been removed from DoD Google Chrome STIG v2r10 Settings Catalog policy. The Google Chrome STIG may retain the setting requirements for these settings. If administrators wish to configure settings, they must complete a manual action to configure endpoints.

Depreciated setting SSLVersionMin has been removed from DoD Microsoft Edge STIG v2r2 Settings Catalog policy. The Microsoft Edge STIG may retain the setting requirement for this setting. If administrators wish to configure setting, they must complete a manual action to configure endpoints.

July 2025
--------------
MS Edge STIG updated EDGE-00-000036 to allow for a value of 4. DoD Microsoft Edge STIG v2r3 Settings Catalog policy retained configuration value of 1. 

Google Chrome STIG updated DTBC-0055 to allow for a value of 4. DoD Google Chrome STIG v2r11 Settings Catalog policy retained configuration value of 1.

Google Chrome STIG v2r11 introduced:
DTBC-0075 - Added requirement to configure Create Themes with AI.
DTBC-0076 - Added requirement to configure DevTools Generative AI features.
DTBC-0077 - Added requirement to configure GenAI local foundational model.
DTBC-0078 - Added requirement to configure Help Me Write.
DTBC-0079 - Added requirement to configure AI-powered History Search.
DTBC-0080 - Added requirement to configure Tab Compare Settings. 
At time of release of Intune STIG Baseline package Generative AI settings unavailable in setting catalog profiles. Intune Policy Baseline contains remediation scripts to detect and configure DTBC-0075, DTBC-0076, and DTBC-0077, and DTBC-0078, and DTBC-0079, and DTBC-0080. The remediation scripts are located under Jul25 DISA STIG Intune Policy Package 0701\Support Files\Windows\PowerShell Scripts\GoogleChromeGenerativeAIConfig directory.


KNOWN ISSUES
------------

Windows 10 Administrative Template Device Configuration Profile - DoD Windows 10 STIG vXrX Administrative Templates
STIG ID WN10-CC-000052 Windows 10 must be configured to prioritize ECC Curve with longer key lengths first setting has been removed from JSON file. Administrators must configure STIG ID WN10-CC-000052 setting after importing device configuration profile into environment. 
The Microsoft Edge macOS Settings Catalog does NOT meet all STIG requirements. There are several settings not available for configuration. Administrators are encouraged to use the Microsoft Edge macOS Preference File profile to meet all STIG requirements.

The checklist files are in DISA STIG GPO Package.

Google Chrome STIG v2r11 app configuration policy does NOT meet all required STIG settings.

Custom policy import scripts do not include the required OMA-URI ADMX ingestion setting. This setting must be configured after importing custom policy in environment.
